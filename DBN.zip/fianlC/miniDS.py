# -*- coding:utf-8 -*-
# 划分数据集
# 此前数据集已被分好为train、valid、test,在此上随机选取 N way K shot
N = 5
K = 1
T1 = 5
T2 = 10

import os
import random
import shutil
from shutil import copy2


datadir_normal = "./omniglot2/new/0/"    # dataset
ways = os.listdir(datadir_normal + "train/")  # 各类名
# 打乱文件顺序
ways_num = len(ways)
way1 = list(range(ways_num))

random.seed()
epoch = 5  # 几组实验
for it in range(epoch):
    random.shuffle(way1)
    way = way1[:N]
    print(way)

    # s.mkdir()只能创建一级目录，应该用os.makedirs()创建多级目录
    trainDir = datadir_normal  + str(it) + "/train/"  # （将训练集放在这个文件夹下）
    os.makedirs(trainDir)
    for i in way:
        os.mkdir(trainDir + ways[i])
    validDir = datadir_normal + str(it) + '/valid/'  # （将验证集放在这个文件夹下）
    os.makedirs(validDir)
    for i in way:
        os.mkdir(validDir + ways[i])
    testDir = datadir_normal + str(it) + '/test/'  # （将测试集放在这个文件夹下）
    os.makedirs(testDir)
    for i in way:
        os.mkdir(testDir + ways[i])



    for i in way:
        new_f1 = trainDir + ways[i]    # 放入的新目录路径
        new_f2 = validDir + ways[i]
        new_f3 = testDir + ways[i]

        f1 = datadir_normal + "train/" + ways[i] # 要放入的图片来源
        f2 = datadir_normal + "valid/" + ways[i]
        f3 = datadir_normal + "test/" + ways[i]

        # 训练集挑选 K shot
        path_file = os.listdir(f1)         # 该路径下的各图片名
        path_file_num = len(path_file)
        index_list = list(range(path_file_num))
        random.shuffle(index_list)
        for i in index_list[:K]:
            fileName = os.path.join(f1, path_file[i])
            copy2(fileName, new_f1)


        # 验证集挑选 T1 个用作测试
        path_file = os.listdir(f2)  # 该路径下的各图片名
        path_file_num = len(path_file)
        index_list = list(range(path_file_num))
        random.shuffle(index_list)
        for i in index_list[:T1]:
            fileName = os.path.join(f2, path_file[i])
            copy2(fileName, new_f2)


        # 测试集挑选 T2 个用作测试
        path_file = os.listdir(f3)  # 该路径下的各图片名
        path_file_num = len(path_file)
        index_list = list(range(path_file_num))
        random.shuffle(index_list)

        for i in index_list[:T2]:
            fileName = os.path.join(f3, path_file[i])
            copy2(fileName, new_f3)