import matplotlib.pyplot as plt
import numpy as np
import torch

dataset = "tiny-imagenet/base/"    # dataset
history = 'models/'+ dataset + '_history.pt'

history = torch.load(history)
history = np.array(history)

plt.plot(history[:, 0:2])
plt.legend(['Tr Loss', 'Val Loss'])
plt.xlabel('Epoch Number')
plt.ylabel('Loss')
# plt.ylim(0, 1)
plt.savefig('models/'+ dataset + '_loss_curve.png')
plt.show()

plt.plot(history[:, 2:4])
plt.legend(['Tr Accuracy', 'Val Accuracy'])
plt.xlabel('Epoch Number')
plt.ylabel('Accuracy')
plt.ylim(0, 1)
plt.savefig('models/'+ dataset + '_accuracy_curve.png')
plt.show()

print(history[:, 0:2])
print()
print(history[:, 2:4])
