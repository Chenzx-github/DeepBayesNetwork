# N WAY K SHOT 测试 并与 resnet 对比
import torch
from torchvision import datasets, models, transforms
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import time
import numpy as np
import matplotlib.pyplot as plt
import os


from sklearn.model_selection import  train_test_split
from sklearn.metrics import confusion_matrix, classification_report
import cv2

bys = []
my = []
res = []
featurel = []

image_transforms = {
    'train': transforms.Compose([
        transforms.RandomResizedCrop(size=256, scale=(0.8, 1.0)),
        transforms.RandomRotation(degrees=15),
        transforms.RandomHorizontalFlip(),
        transforms.CenterCrop(size=224),
        transforms.Resize(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ]),
    'valid': transforms.Compose([
        transforms.Resize(size=256),
        transforms.CenterCrop(size=224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ]),
    'test': transforms.Compose([
        transforms.Resize(size=256),
        transforms.CenterCrop(size=224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ])
}


datadir = "CIFAR-FS2/base/"    # dataset
ways = os.listdir(datadir)
ways_num = len(ways)



for i in range(ways_num):
    print("this is ",i+1,"epoch")

    dataset = datadir + str(i)
    new_dir = dataset + '/models/'
    if not os.path.exists(new_dir):
        os.makedirs(new_dir)
    train_directory = os.path.join(dataset, 'train')
    valid_directory = os.path.join(dataset, 'valid')
    test_directory = os.path.join(dataset, 'test')

    batch_size = 32

    data = {
    'train': datasets.ImageFolder(root=train_directory, transform=image_transforms['train']),
    'valid': datasets.ImageFolder(root=valid_directory, transform=image_transforms['valid']),
    'test': datasets.ImageFolder(root=test_directory, transform=image_transforms['test'])

    }
    train_data = DataLoader(data['train'], batch_size=batch_size, shuffle=True)
    valid_data = DataLoader(data['valid'], batch_size=batch_size, shuffle=True)
    test_data = DataLoader(data['test'], batch_size=batch_size, shuffle=True)
    print(len(train_data))

    train_data_size = len(data['train'])
    valid_data_size = len(data['valid'])
    test_data_size = len(data['test'])
    print(train_data_size, valid_data_size, test_data_size)



    # 引入迁移学习,并修改网络分类器结构，注意 train_data和valid_data 需要保留

    # base
    resnet18 = models.resnet18(pretrained=True)

    # # new
    # resnet18=torch.load("models/CIFAR-FS/_model_1.pt") # 调用
    # resnet18.eval()
    # for param in resnet18.parameters():
    #     param.requires_grad = False

    #将ResNet-50的最后一层替换为一个有256个输出单元的线性层,再连接ReLU层和Dropout层，然后是256 x 10的线性层，输出为10通道的softmax层
    # base
    num_classes = 80
    fc_inputs = resnet18.fc.in_features          # (fc): Linear(in_features=512, out_features=1000, bias=True)
    resnet18.fc = nn.Sequential(
        nn.Linear(fc_inputs, 256),
        nn.ReLU(),
        nn.Dropout(0.4),
        nn.Linear(256, num_classes),         # 修改分类识别的数目
        nn.LogSoftmax(dim=1)
    )

    # # new
    # num_classes = 20
    # resnet18.fc = nn.Sequential(
    #     nn.Linear(512, 64),
    #     nn.ReLU(),
    #     nn.Dropout(0.4),
    #     nn.Linear(64, num_classes),         # 修改分类识别的数目
    #     nn.LogSoftmax(dim=1)
    # )

    resnet18 = resnet18.to('cuda:0')

    # 定义损失函数和优化器
    loss_func = nn.NLLLoss()
    optimizer = optim.Adam(resnet18.parameters())

    # 训练
    def train_and_valid(model, loss_function, optimizer, epochs=25):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        history = []
        best_acc = 0.0
        best_epoch = 0

        for epoch in range(epochs):
            epoch_start = time.time()
            print("Epoch: {}/{}".format(epoch + 1, epochs))

            model.train()

            train_loss = 0.0
            train_acc = 0.0
            valid_loss = 0.0
            valid_acc = 0.0

            for i, (inputs, labels) in enumerate(train_data):
                inputs = inputs.to(device)
                labels = labels.to(device)

                # 因为这里梯度是累加的，所以每次记得清零
                optimizer.zero_grad()

                outputs = model(inputs)

                loss = loss_function(outputs, labels)

                loss.backward()

                optimizer.step()

                train_loss += loss.item() * inputs.size(0)

                ret, predictions = torch.max(outputs.data, 1)
                correct_counts = predictions.eq(labels.data.view_as(predictions))

                acc = torch.mean(correct_counts.type(torch.FloatTensor))

                train_acc += acc.item() * inputs.size(0)

            with torch.no_grad():
                model.eval()

                for j, (inputs, labels) in enumerate(valid_data):
                    inputs = inputs.to(device)
                    labels = labels.to(device)

                    outputs = model(inputs)

                    loss = loss_function(outputs, labels)

                    valid_loss += loss.item() * inputs.size(0)

                    ret, predictions = torch.max(outputs.data, 1)
                    correct_counts = predictions.eq(labels.data.view_as(predictions))

                    acc = torch.mean(correct_counts.type(torch.FloatTensor))

                    valid_acc += acc.item() * inputs.size(0)

            avg_train_loss = train_loss / train_data_size
            avg_train_acc = train_acc / train_data_size

            avg_valid_loss = valid_loss / valid_data_size
            avg_valid_acc = valid_acc / valid_data_size

            history.append([avg_train_loss, avg_valid_loss, avg_train_acc, avg_valid_acc])

            if best_acc < avg_valid_acc:
                best_acc = avg_valid_acc
                best_epoch = epoch + 1

            epoch_end = time.time()

            print(
                "Epoch: {:03d}, Training: Loss: {:.4f}, Accuracy: {:.4f}%, \n\t\tValidation: Loss: {:.4f}, Accuracy: {:.4f}%, Time: {:.4f}s".format(
                    epoch + 1, avg_valid_loss, avg_train_acc * 100, avg_valid_loss, avg_valid_acc * 100,
                    epoch_end - epoch_start
                ))
            print("Best Accuracy for validation : {:.4f} at epoch {:03d}".format(best_acc, best_epoch))

            # # base
            # torch.save(model, 'models/' + "CIFAR-FS2/" +'_model_' + str(epoch + 1) + '.pt')
            # model=torch.load(mymodel.pth) # 调用
            # model.eval()
        return model, history


    # 1 3 进行已预训练ResNet上的再训练
    num_epochs = 200
    trained_model, history = train_and_valid(resnet18, loss_func, optimizer, num_epochs) # trained_model 为训练后的模型
    # torch.save(history, 'models/'+ datadir + '_history.pt')


    # history = np.array(history)
    # plt.plot(history[:, 0:2])
    # plt.legend(['Tr Loss', 'Val Loss'])
    # plt.xlabel('Epoch Number')
    # plt.ylabel('Loss')
    # plt.ylim(0, 1)
    # plt.savefig(dataset + '_loss_curve.png')
    # plt.show()
    #
    # plt.plot(history[:, 2:4])
    # plt.legend(['Tr Accuracy', 'Val Accuracy'])
    # plt.xlabel('Epoch Number')
    # plt.ylabel('Accuracy')
    # plt.ylim(0, 1)
    # plt.savefig(dataset + '_accuracy_curve.png')
    # plt.show()


    def forward(model, x):
        x = model.conv1(x)
        x = model.bn1(x)
        x = model.relu(x)
        x = model.maxpool(x)
        x = model.layer1(x)
        x = model.layer2(x)
        x = model.layer3(x)
        x = model.layer4(x)
        x = model.avgpool(x)
        x = x.view(x.size(0), -1)
        return x


    def softmax(Y_predict):
        # 返回各类别百分比列表
        p = [[] for i in range(len(Y_predict))]
        for i in range(len(Y_predict)):
            maxn = max(Y_predict[i])
            minn = min(Y_predict[i])
            for j in Y_predict[i]:
                tmp = (j - minn) / (maxn - minn)
                p[i].append(math.exp(tmp))
            p[i] = [x / sum(p[i]) for x in p[i]]

        return p

    # 贝叶斯分类器
    from sklearn.preprocessing import binarize
    from sklearn.preprocessing import LabelBinarizer
    import math
    class ML:
        def predict(self, x):
            # 预测最终分类标签和各类别概率
            X = binarize(x, threshold=self.threshold)

            X1 = []
            for item in X.tolist():
                item = item[:]
                X1.append(item)
            X1 = np.array(X1)

            # 使对数似然函数最大的值也使似然函数最大
            # Y_predict = np.dot(X, np.log(prob).T)+np.dot(np.ones((1,prob.shape[1]))-X, np.log(1-prob).T)
            # 等价于  lnf(x)=xlnp+(1-x)ln(1-p)
            Y_predict = np.dot(X1, np.log(self.prob).T) - np.dot(X1, np.log(1 - self.prob).T) + np.log(
                1 - self.prob).sum(
                axis=1)
            # print(Y_predict.shape)
            # print(np.argmax(Y_predict, axis=1).shape)
            # print(np.argmax(Y_predict, axis=1))

            return self.classes[np.argmax(Y_predict, axis=1)], Y_predict.tolist()

            # 统计特征概率，返回测试样例 X2 中的特征概率列表

        def confidence(self, X1, X2):

            X1 = binarize(X1, threshold=self.threshold)
            X2 = binarize(X2, threshold=self.threshold)

            x1 = []
            for item in X1.tolist():
                item = item[:]
                x1.append(item)
            x1 = np.array(x1)
            a = np.sum(x1, axis=0)
            a = a / len(x1)
            print(min(a))
            feature = {}
            for i in range(len(a)):
                # 0.2 重要参数可更改
                if a[i] >= 0.2: feature[i] = a[i]
            print("feature 的长度为", len(feature))
            # print(len(feature))
            # print(max(feature.values()),min(feature.values()))

            x2 = []
            for item in X2.tolist():
                item = item[:]
                x2.append(item)
            x2 = np.array(x2)

            res = []
            for item in x2:
                p = 1
                for j in range(len(item)):
                    if j in feature:
                        if item[j] == 1:
                            # if a[j] < 1/len(x1):
                            #     a[j] = 1/len(x1)
                            p = p * feature[j]
                        else:
                            # if a[j] == 1:
                            #     a[j] == 1 - 1/len(x1)
                            if feature[j] == 1.0:
                                p = p * 0.01
                            else:
                                p = p * (1 - feature[j])
                res.append(p)
            # print(len(res))
            # count = 0
            # for i in res:
            #     if i:count += 1
            # print(count)
            # print(max(res),min(res))
            return res

    class Bayes(ML):
        def __init__(self, threshold):
            self.threshold = threshold
            self.classes = []
            self.prob = 0.0

        def fit(self, X, y):
            # 标签二值化
            labelbin = LabelBinarizer()
            Y = labelbin.fit_transform(y)
            self.classes = labelbin.classes_  # 统计总的类别
            Y = Y.astype(np.float64)

            # 转换成二分类问题
            X = binarize(X, threshold=self.threshold)  # 特征二值化,threshold阈值根据自己的需要适当修改

            X1 = []
            for item in X.tolist():
                item = item[:]
                X1.append(item)
            X1 = np.array(X1)

            feature_count = np.dot(Y.T, X1)  # 矩阵转置，对相同特征进行融合
            class_count = Y.sum(axis=0)  # 统计每一类别出现的个数

            # 拉普拉斯平滑处理，解决零概率的问题
            alpha = 1.0
            smoothed_fc = feature_count + alpha
            # print(smoothed_fc)
            smoothed_cc = class_count + alpha * 2
            # print(smoothed_cc)
            self.prob = smoothed_fc / smoothed_cc.reshape(-1, 1)
            # print(self.prob)

            return self



    import datetime
    starttime = datetime.datetime.now()
    import numpy as np
    from sklearn.model_selection import  train_test_split
    from sklearn.metrics import confusion_matrix, classification_report
    import os
    import cv2

    print("______________________test____________________")
    # 将训练集和验证集特征向量展开，后续开集判断需要用到特征向量


    X_train=[]
    y_train=[]
    featureSum_train = []
    traindir = './' + dataset + '/train/'         # 确定数据集 开始测试集
    list = os.listdir(traindir)
    for i in range(0, len(list)):
        # 遍历文件夹，读取图片
        he = 0
        lists = os.listdir(traindir + "%s" % list[i])
        for f in os.listdir(traindir + "%s" % list[i]):
            Img = cv2.imread(traindir + "%s/%s" % (list[i], f)) # f 为图片名，list[i]为类名
            img = cv2.resize(Img, (256, 256))
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            transform = transforms.Compose(
                [transforms.ToTensor(),
                 transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
            img = transform(img).cuda()
            img = img.unsqueeze(0)
            X_train.append(forward(trained_model,img).data.cpu().numpy()[0])

            he += sum(forward(trained_model,img).data.cpu().numpy()[0])
            y_train.append(i)
        featureSum_train.append(he / len(lists))
    X_train = np.array(X_train)
    y_train = np.array(y_train)
    featurel.append(np.mean(featureSum_train))


    X_test = []
    y_test = []
    featureSum_test = []#测试集特征向量和
    testdir = './' + dataset + '/test/'
    y1_test = []# softmax 的预测标签
    pre2 = []# softmax 的各分类概率结果
    for i in range(0, len(list)):
        # 遍历文件夹，读取图片
        for f in os.listdir(testdir + "%s" % list[i]):
            # 打开一张图片并灰度化
            Img = cv2.imread(testdir + "%s/%s" % (list[i], f))
            img = cv2.resize(Img, (256, 256))
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            transform = transforms.Compose(
                [transforms.ToTensor(),
                 transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
            img = transform(img).cuda()
            img = img.unsqueeze(0)

            X_test.append(forward(trained_model, img).data.cpu().numpy()[0])
            featureSum_test.append(sum(forward(trained_model, img).data.cpu().numpy()[0]))
            y_test.append(i)

            out = trained_model(img)
            pre2.append(out.cpu().detach().numpy().tolist()[0])
            ret, predictions = torch.max(out.data, 1)
            y1_test.append(predictions.cpu().numpy()[0])


    X_test = np.array(X_test)
    y_test = np.array(y_test)
    # print(featureSum_test)

    clf0 = Bayes(0.05).fit(X_train, y_train)
    predictions_labels, pre1 = clf0.predict(X_test)

    # 预测概率
    pre1 = softmax(pre1)
    pre2 = softmax(pre2)

    # print(classification_report(y_test, predictions_labels))
    # print(classification_report(y_test, y1_test))

    # t1 = classification_report(y_test, predictions_labels, output_dict=True)
    # t2 = classification_report(y_test, y1_test, output_dict=True)

    finalLabel = []
    for i in range(len(y_test)):
        label1 = predictions_labels[i]
        label2 = y1_test[i]
        if label1 == label2:
            finalLabel.append(label1)
        else:
            # 调出该概率
            pro1 = max(pre1[i])
            pro2 = max(pre2[i])
            featureSum = featureSum_test[i]#805 675 CIFRA 739
            if featureSum > 880:finalLabel.append(label2)#880
            elif featureSum < 680:finalLabel.append(label1)#616
            else:
                if pro1 >= pro2 * (1 + 0):finalLabel.append(label1)
                else:finalLabel.append(label2)

    # print(classification_report(y_test, finalLabel))
    # print(y_test)
    # print(finalLabel)
    # print(featurel[-1])
    import sklearn

    bys.append(sklearn.metrics.accuracy_score(y_test, predictions_labels))
    my.append(sklearn.metrics.accuracy_score(y_test, finalLabel))
    res.append(sklearn.metrics.accuracy_score(y_test, y1_test))

print(res)
print(bys)
print(my)

# print(h)
print(np.mean(featurel),np.var(featurel))
print(max(featurel),min(featurel))



# Bys = [0.13575493981376335] * 10
# resnetl = [0.7897851757006686, 0.8699111505554337, 0.8982551571235782, 0.8974263322884012, 0.9050802139037433, 0.8981688423132932, 0.8897148603030957, 0.9061339096533605, 0.9087251338680037, 0.9067711558307533]
# resnetBys = [0.9485005332831419, 0.9436231884057971, 0.9168374741200827, 0.8962259073243055, 0.8933577928779167, 0.8964646464646464, 0.8723362230267602, 0.871878081237349, 0.8711387328664216, 0.871878081237349]
# import matplotlib.pyplot as plt
# plt.plot(Bys)
# plt.plot(resnetl)
# plt.plot(resnetBys)
# plt.legend(["Bys","Resnet","Resnet-NB"])
# plt.xlabel('Epoch Number')
# plt.ylabel('Precision_Score')
# plt.ylim(0, 1)
# plt.show()

# 0.05954136848449707
