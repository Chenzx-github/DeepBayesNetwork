import torch
from torchvision import datasets, models, transforms
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import time
import numpy as np
import matplotlib.pyplot as plt
import os
import sklearn


from sklearn.model_selection import  train_test_split
from sklearn.metrics import confusion_matrix, classification_report
import cv2


bys = []
my = []
res = []
t = []
n = []
featurel = []

image_transforms = {
    'train': transforms.Compose([
        transforms.RandomResizedCrop(size=256, scale=(0.8, 1.0)),
        transforms.RandomRotation(degrees=15),
        transforms.RandomHorizontalFlip(),
        transforms.CenterCrop(size=224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ]),
    'valid': transforms.Compose([
        transforms.Resize(size=256),
        transforms.CenterCrop(size=224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ]),
    'test': transforms.Compose([
        transforms.Resize(size=256),
        transforms.CenterCrop(size=224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ])
}


datadir = "cifar10/osr/"    # dataset
ways = os.listdir(datadir)
ways_num = len(ways)



for i in range(ways_num):
    print("this is ",i+1,"epoch")

    dataset = datadir + str(i)
    new_dir = dataset + '/models/'
    if not os.path.exists(new_dir):
        os.makedirs(new_dir)
    train_directory = os.path.join(dataset, 'train')
    valid_directory = os.path.join(dataset, 'valid')
    test_directory = os.path.join(dataset, 'test')

    batch_size = 32


    data = {
    'train': datasets.ImageFolder(root=train_directory, transform=image_transforms['train']),
    'valid': datasets.ImageFolder(root=valid_directory, transform=image_transforms['valid']),
    'test': datasets.ImageFolder(root=test_directory, transform=image_transforms['test'])

    }
    train_data = DataLoader(data['train'], batch_size=batch_size, shuffle=True)
    valid_data = DataLoader(data['valid'], batch_size=batch_size, shuffle=True)
    test_data = DataLoader(data['test'], batch_size=batch_size, shuffle=True)

    train_data_size = len(data['train'])
    valid_data_size = len(data['valid'])
    test_data_size = len(data['test'])
    print(train_data_size, valid_data_size, test_data_size)



    # 引入迁移学习,并修改网络分类器结构，注意 train_data和valid_data 需要保留
    # resnet18 = models.resnet18(pretrained=True)

    resnet18 = torch.load("models/cifar/base/osr_model_" + str(i + 1) + ".pt")  # 调用
    resnet18.eval()
    # resnet18 = torch.load("models/tiny-imagenet/base/_model_037.pt")  # 调用
    # resnet18.eval()
    for param in resnet18.parameters():
        param.requires_grad = False
        #为了适应自己的数据集，将ResNet-50的最后一层替换为，将原来最后一个全连接层的输入喂给一个有256个输出单元的线性层
        #  接着再连接ReLU层和Dropout层，然后是256 x 10的线性层，输出为10通道的toperCent层

    num_classes = 6
    # fc_inputs = resnet18.fc.in_features
    # resnet18.fc = nn.Sequential(
    #     nn.Linear(fc_inputs, 256),
    #     nn.ReLU(),
    #     nn.Dropout(0.4),
    #     nn.Linear(256, num_classes),         # 修改分类识别的数目
    #     nn.LogSoftmax(dim=1)
    # )

    resnet18 = resnet18.to('cuda:0')

    # 定义损失函数和优化器
    loss_func = nn.NLLLoss()
    optimizer = optim.Adam(resnet18.parameters())

    # 训练
    def train_and_valid(model, loss_function, optimizer, epochs=25):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        history = []
        best_acc = 0.0
        best_epoch = 0

        for epoch in range(epochs):
            epoch_start = time.time()
            print("Epoch: {}/{}".format(epoch + 1, epochs))

            model.train()

            train_loss = 0.0
            train_acc = 0.0
            valid_loss = 0.0
            valid_acc = 0.0

            for i, (inputs, labels) in enumerate(train_data):
                inputs = inputs.to(device)
                labels = labels.to(device)

                # 因为这里梯度是累加的，所以每次记得清零
                optimizer.zero_grad()

                outputs = model(inputs)

                loss = loss_function(outputs, labels)

                loss.backward()

                optimizer.step()

                train_loss += loss.item() * inputs.size(0)

                ret, predictions = torch.max(outputs.data, 1)
                correct_counts = predictions.eq(labels.data.view_as(predictions))

                acc = torch.mean(correct_counts.type(torch.FloatTensor))

                train_acc += acc.item() * inputs.size(0)

            with torch.no_grad():
                model.eval()

                for j, (inputs, labels) in enumerate(valid_data):
                    inputs = inputs.to(device)
                    labels = labels.to(device)

                    outputs = model(inputs)

                    loss = loss_function(outputs, labels)

                    valid_loss += loss.item() * inputs.size(0)

                    ret, predictions = torch.max(outputs.data, 1)
                    correct_counts = predictions.eq(labels.data.view_as(predictions))

                    acc = torch.mean(correct_counts.type(torch.FloatTensor))

                    valid_acc += acc.item() * inputs.size(0)

            avg_train_loss = train_loss / train_data_size
            avg_train_acc = train_acc / train_data_size

            avg_valid_loss = valid_loss / valid_data_size
            avg_valid_acc = valid_acc / valid_data_size

            history.append([avg_train_loss, avg_valid_loss, avg_train_acc, avg_valid_acc])

            if best_acc < avg_valid_acc:
                best_acc = avg_valid_acc
                best_epoch = epoch + 1

            epoch_end = time.time()

            print(
                "Epoch: {:03d}, Training: Loss: {:.4f}, Accuracy: {:.4f}%, \n\t\tValidation: Loss: {:.4f}, Accuracy: {:.4f}%, Time: {:.4f}s".format(
                    epoch + 1, avg_train_loss, avg_train_acc * 100, avg_valid_loss, avg_valid_acc * 100,
                    epoch_end - epoch_start
                ))
            print("Best Accuracy for validation : {:.4f} at epoch {:03d}".format(best_acc, best_epoch))

            # torch.save(model, 'models/tiny-imagenet/' + '_model_' + str(epoch + 1) + '.pt')
        return model, history


        # 1 3 进行已预训练ResNet上的再训练
    num_epochs = 0
    trained_model, history = train_and_valid(resnet18, loss_func, optimizer, num_epochs) # trained_model 为训练后的模型
    # torch.save(history, 'models/' +  "tiny-imagenet/base/" + '_history.pt')

    def forward(model, x):
        x = model.conv1(x)
        x = model.bn1(x)
        x = model.relu(x)
        x = model.maxpool(x)
        x = model.layer1(x)
        x = model.layer2(x)
        x = model.layer3(x)
        x = model.layer4(x)
        x = model.avgpool(x)
        x = x.view(x.size(0), -1)
        return x

    def toperCent(Y_predict):
        # 返回各类别百分比列表
        p = [[] for i in range(len(Y_predict))]
        for i in range(len(Y_predict)):
            maxn = max(Y_predict[i])
            minn = min(Y_predict[i])
            for j in Y_predict[i]:
                if maxn - minn:
                    tmp = (j - minn) / (maxn - minn)
                    p[i].append(math.exp(tmp))
                else:
                    p[i].append(1.0 / len(Y_predict[i]))
            p[i] = [x / sum(p[i]) for x in p[i]]
        return p


    # def draw_hist(lenths):  # lenths 接受的其实是 sizeArry传来的数组 就是def get_data(lines) 返回的数据
    #     data = lenths
    #
    #     # 对数据进行切片，将数据按照从最小值到最大值分组，分成20组
    #     bins = np.linspace(min(data), max(data), 20)
    #
    #     # 这个是调用画直方图的函数，意思是把数据按照从bins的分割来画
    #     plt.hist(data, bins)
    #     # 设置出横坐标
    #     plt.xlabel('Number of ×××')
    #     # 设置纵坐标的标题
    #     plt.ylabel('Number of occurences')
    #     # 设置整个图片的标题
    #     plt.title('Frequency distribution of number of ×××')
    #
    #     # 展示出我们的图片
    #     plt.show()

    # 统计特征概率，返回测试样例 X2 中的特征概率列表
    def confidence(fp, x1):

        shold = fp.mean()
        fp = binarize(fp.reshape(1,-1), threshold=shold)
        res = sklearn.metrics.mean_squared_error(fp[0], x1)
        return res

    # def confidence(X1, X2, shold=0.05):
    #     import math
    #
    #     # X1 = binarize(X1, threshold=shold)
    #     # X2 = binarize(X2, threshold=shold)
    #
    #     x1 = []
    #     for item in X1.tolist():
    #         item = item[:]
    #         x1.append(item)
    #     x1 = np.array(x1)
    #     a = x1.mean(axis=0)
    #     # plt.plot(a)
    #     # plt.show()
    #     b = x1.std(axis=0)
    #     print(len(a), len(b))
    #
    #     x2 = []
    #     for item in X2.tolist():
    #         item = item[:]
    #         x2.append(item)
    #     x2 = np.array(x2)
    #
    #     res = []
    #     for item in x2:
    #         p = 1.0
    #         for j in range(len(item)):
    #             v = b[j]
    #             m = a[j]
    #             # p = p / (math.sqrt(2 * math.pi) * v) * math.exp(- (item[j] - m) ** 2 / (2 * v ** 2))
    #             p =  p * ( - pow(item[j] - m,2) / (2 * pow(v,2)) - np.log(1.0 / math.sqrt(2 * math.pi) * v))
    #         res.append(p)
    #     draw_hist(res)
    #     return res

    # 贝叶斯分类器
    from sklearn.preprocessing import binarize
    from sklearn.preprocessing import LabelBinarizer
    import math
    class ML:
        def predict(self, x):
            # 预测最终分类标签和各类别概率
            X = binarize(x, threshold=self.threshold)

            X1 = []
            for item in X.tolist():
                item = item[:]
                X1.append(item)
            X1 = np.array(X1)
            # x1*log(p) - x1*log(1-p) + log(1-p)
            # (N,512)*(512,20) - (N,512)*(512,20) + (1,20) -> (N,20)
            Y_predict = np.dot(X1, np.log(self.prob).T) - np.dot(X1, np.log(1 - self.prob).T) + np.log(1 - self.prob).sum(axis=1)
            percent = toperCent(Y_predict.tolist())

            confidenceRE = []
            mm = np.argmax(Y_predict, axis=1)
            for i in range(len(X1)):
                confidenceRE.append(confidence(self.prob[mm[i]], X1[i]))

            return self.classes[np.argmax(Y_predict, axis=1)], percent, confidenceRE


    class Bayes(ML):
        def __init__(self, threshold):
            self.threshold = threshold
            self.classes = []
            self.prob = 0.0
            self.featureProb = np.array([])

        def fit(self, X, y):
            # 标签二值化
            labelbin = LabelBinarizer()
            Y = labelbin.fit_transform(y)
            self.classes = labelbin.classes_  # 统计总的类别
            Y = Y.astype(np.float64)

            # 转换成二分类问题
            X = binarize(X, threshold=self.threshold)  # 特征二值化,threshold阈值根据自己的需要适当修改

            X1 = []
            for item in X.tolist():
                item = item[:]
                X1.append(item)
            X1 = np.array(X1)


            feature_count = np.dot(Y.T, X1)  # 矩阵转置，对相同特征进行融合 (20, 10000) (10000, 512) ->(20,512)
            class_count = Y.sum(axis=0)  # 统计每一类别出现的个数
            # print(Y.shape, X1.shape, class_count.shape)  (10000, 20) (10000, 512) (20,)

            # 拉普拉斯平滑处理，解决零概率的问题
            alpha = 1.0
            smoothed_fc = feature_count + alpha
            # (20,512)
            smoothed_cc = class_count + alpha * 2
            # (20,)
            self.prob = smoothed_fc / smoothed_cc.reshape(-1, 1)
            # (20,512) / (1,20) = (20, 512)
            # for i in self.prob:
            #     draw_hist(i)

            
            self.featureProb = feature_count.sum(axis = 0) / X1.shape[0]
            # print(sum(np.log(self.featureProb)))


            return self



    import datetime
    starttime = datetime.datetime.now()
    import numpy as np
    from sklearn.model_selection import  train_test_split
    from sklearn.metrics import confusion_matrix, classification_report
    import os
    import cv2

    print("______________________test____________________")
    # 将训练集和验证集特征向量展开，后续开集判断需要用到特征向量

    X_train=[]
    y_train=[]
    y1_train = []
    featureSum_train = []
    traindir = './' + dataset + '/train/'         # 确定数据集 开始测试集
    labellist = os.listdir(traindir)
    for i in range(0, len(labellist)):
        # 遍历文件夹，读取图片
        he = 0
        lists = os.listdir(traindir + "%s" % labellist[i])
        for f in os.listdir(traindir + "%s" % labellist[i]):
            Img = cv2.imread(traindir + "%s/%s" % (labellist[i], f)) # f 为图片名，list[i]为类名
            img = cv2.resize(Img, (256, 256))
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            transform = transforms.Compose(
                [transforms.ToTensor(),
                 transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
            img = transform(img).cuda()
            img = img.unsqueeze(0)
            X_train.append(forward(trained_model,img).data.cpu().numpy()[0])
            he += sum(forward(trained_model,img).data.cpu().numpy()[0])

            y_train.append(labellist[i])

            out = trained_model(img)
            ret, predictions = torch.max(out.data, 1)
            y1_train.append(labellist[predictions.cpu().numpy()[0]])

        featureSum_train.append(he / len(lists))
    X_train = np.array(X_train)
    y_train = np.array(y_train)
    featurel.append(np.mean(featureSum_train))


    # fun = {}  # fun存储训练集各类别特征概率
    # for i in range(len(labellist)):
    #     fun[labellist[i]] = []
    # print(fun)

    # X_valid = []
    # y_valid = []
    # # y1_valid = []  # toperCent 的预测标签
    # # pre2 = []
    # validdir = './' + dataset + '/valid/'  # 确定数据集 开始测试集
    # labellist = os.listdir(validdir)
    # for i in range(0, len(labellist)):
    #     # 遍历文件夹，读取图片
    #     he = 0
    #     lists = os.listdir(validdir + "%s" % labellist[i])
    #     for f in os.listdir(validdir + "%s" % labellist[i]):
    #         Img = cv2.imread(validdir + "%s/%s" % (labellist[i], f))  # f 为图片名，list[i]为类名
    #         img = cv2.resize(Img, (256, 256))
    #         img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    #         transform = transforms.Compose(
    #             [transforms.ToTensor(),
    #              transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
    #         img = transform(img).cuda()
    #         img = img.unsqueeze(0)
    #         X_valid.append(forward(trained_model, img).data.cpu().numpy()[0])
    #
    #         he += sum(forward(trained_model, img).data.cpu().numpy()[0])
    #
    #         y_valid.append(labellist[i])

            # out = trained_model(img)
            # pre2.append(out.cpu().detach().numpy().tolist()[0])
            # ret, predictions = torch.max(out.data, 1)
            # y1_valid.append(labellist[predictions.cpu().numpy()[0]])

        # featureSum_train.append(he / len(lists))
    # X_valid = np.array(X_valid)
    # y_valid = np.array(y_valid)



    X_test = []
    num_nei = 0
    num_wai = 0
    featureSum_test = []#测试集特征向量
    testdir = './' + dataset + '/test/'
    y1_test = []# toperCent 的预测标签
    pre2 = []# toperCent 的各分类概率结果
    list = os.listdir(testdir)
    for i in range(0, len(list)):
        # 遍历文件夹，读取图片
        for f in os.listdir(testdir + "%s" % list[i]):
            if list[i] == "10":num_nei += 1
            if list[i] == "11":num_wai += 1
            # 打开一张图片并灰度化
            Img = cv2.imread(testdir + "%s/%s" % (list[i], f))
            img = cv2.resize(Img, (256, 256))
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            transform = transforms.Compose(
                [transforms.ToTensor(),
                 transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
            img = transform(img).cuda()
            img = img.unsqueeze(0)

            X_test.append(forward(trained_model, img).data.cpu().numpy()[0])
            featureSum_test.append(sum(forward(trained_model, img).data.cpu().numpy()[0]))

    X_test = np.array(X_test)

    fs = 0.05
    clf0 = Bayes(fs).fit(X_train, y_train)
    _, trainPercent, trainRes = clf0.predict(X_train)
    # _, validPercent, validRes = clf0.predict(X_valid)
    predictions_labels, testPercent, testRes = clf0.predict(X_test)


    aa = np.mean(trainRes)
    bb = np.std(trainRes)
    # print(aa,bb)
    # plt.plot(trainRes)
    # plt.show()
    # print(max(validRes), min(validRes))
    # plt.plot(validRes)
    # plt.show()

    # f = []
    # for i in pre1:
    #     f.append(max(i))
    #
    # plt.plot(f)
    # plt.show()
    # print(max(f),min(f))


    # print("bys",sklearn.metrics.accuracy_score(y_valid, predictions_labels))

    # # 开集测试
    # print(len(X_train),len(X_valid),len(X_test))
    #
    # trainRes = confidence(X_train, X_train)
    # print("trainRes", min(trainRes), max(trainRes))



    #
    # validRes = confidence(X_train, X_valid)
    # print("validRes", min(validRes), max(validRes))





    # testRes = confidence(X_train, X_test[:20])
    # print(testRes)
    # testRes = confidence(X_train, X_test[20:])
    # print(testRes)
    # testRes = confidence(X_train, X_test)



    # count = 0
    # for i in testRes:
    #     if i == 0: count += 1
    # print("总个数", len(X_test))
    # print("testRes 0的个数", count)

    # testConfidence = 分类概率 * 特征概率
    # finalLabel = predictions_labels
    # predictions_distribution = toperCent(testRes)
    # predictions_maxdistribution = [max(x) for x in predictions_distribution]
    # testConfidence = []
    # for i in range(len(testRes)):
    #     testConfidence.append(testRes[i] * predictions_maxdistribution[i])
    # print(max(testConfidence), min(testConfidence))

    testConfidence = testRes

    # trainConfidence = trainRes
    #
    # for i in range(len(y_train)):
    #     fun[y_train[i]].append(trainConfidence[i])
    # for i in fun:
    #     print(max(fun[i]),min(fun[i]))


    print(len(X_test),num_wai,num_nei)
    print("----------------------------------------------------------------")
    print("类别内数据集判断")
    count1 = 0
    for i in range(num_nei):
        # if min(fun[finalLabel[i]]) <= testConfidence[i] <= max(fun[finalLabel[i]]):
        if aa - bb <= testConfidence[i] <= aa + bb:
            count1 += 1
    print("test 类别内粗略判断 TP 正确率", count1 / num_nei)

    Rcount = 0
    Wcount = 0
    w1 = 0
    w2 = 0
    w3 = 0
    # num_classess = 20
    for i in range(num_nei):

        flag = True  # 先默认为类别内
        dis = testPercent[i]
        dis.sort(reverse=True)  # 对各类别概率排序
        if not aa - bb <= testConfidence[i] <= aa + bb:
            flag = False
            w1 += 1
        if (dis[0] - dis[1]) / dis[0] <= 0.05:
            flag = False
            w2 += 1
        if sum(1 for i in dis if i > 1.0 / num_classes) > (num_classes+1) / 2:
            flag = False
            w3 += 1

        if flag:
            Rcount += 1
        else:
            Wcount += 1

    print("test 类别内判断 TP 正确率", Rcount / num_nei)
    if Wcount:
        print("错误占比", w1 / Wcount, w2 / Wcount, w3 / Wcount)
    t.append(Rcount / num_nei)



    # 类别外数据集判断
    print("----------------------------------------------------------------")
    print("类别外数据集判断")

    count1 = 0
    for i in range(num_nei,len(X_test)):
        # if not  min(fun[finalLabel[i]]) <= testConfidence[i] <=  max(fun[finalLabel[i]]):
        if not aa - bb <= testConfidence[i] <= aa + bb:
            count1 += 1

    print("test 类别外粗略判断 TN 正确率", count1 / num_wai)

    Wcount = 0
    Rcount = 0
    waith = []
    w1 = 0
    w2 = 0
    w3 = 0


    for i in range(num_nei,len(X_test)):

        flag = True
        dis = testPercent[i]
        dis.sort(reverse=True)

        if not aa - bb <= testConfidence[i] <= aa + bb:
            flag = False
            w1 += 1
        if (dis[0] - dis[1]) / dis[0] <= 0.05:
            flag = False
            w2 += 1
        if sum(1 for i in dis if i > 1.0 / num_classes) > (num_classes+1) / 2:
            flag = False
            w3 += 1


        if flag:
            Wcount += 1
        else:
            Rcount += 1

    print("test 类别外判断 TN 正确率", Rcount / num_wai)
    if Wcount:
        print("正确占比", w1 / Rcount, w2 / Rcount, w3 / Rcount)
    n.append(Rcount / num_wai)

print(t)
print(n)
# print(np.mean(featurel),np.var(featurel))





